@echo off
setlocal
cd /d "%~dp0"

where jpackage >nul 2>nul
if errorlevel 1 (
    echo ERREUR : jpackage est introuvable. Installez un JDK 17+ et ajoutez bin au PATH.
    exit /b 1
)
if not exist "lib\mysql-connector-j-8.4.0.jar" (
    echo ERREUR : lib\mysql-connector-j-8.4.0.jar est requis.
    exit /b 1
)
if not exist "lib\LICENSE-mysql-connector-j.txt" (
    echo ERREUR : le fichier de licence du pilote JDBC est absent.
    exit /b 1
)
if not exist "lib\mysql-connector-j-8.4.0-sources.jar" (
    echo ERREUR : les sources du pilote JDBC sont requises pour le livrable.
    exit /b 1
)
if exist "build\package-input" (
    echo ERREUR : build\package-input existe deja. Supprimez uniquement ce dossier genere, puis recommencez.
    exit /b 1
)
if exist "dist\ReservationClient" (
    echo ERREUR : dist\ReservationClient existe deja. Supprimez les sorties generees avant de recommencer.
    exit /b 1
)
if exist "dist\ReservationServer" (
    echo ERREUR : dist\ReservationServer existe deja. Supprimez les sorties generees avant de recommencer.
    exit /b 1
)
if exist "dist\ReservationApp-Windows.zip" (
    echo ERREUR : dist\ReservationApp-Windows.zip existe deja. Supprimez les sorties generees avant de recommencer.
    exit /b 1
)

call build.bat
if errorlevel 1 exit /b 1

mkdir "build\package-input\lib"
if errorlevel 1 exit /b 1
copy /Y "lib\mysql-connector-j-8.4.0.jar" "build\package-input\lib\"
if errorlevel 1 exit /b 1
copy /Y "lib\LICENSE-mysql-connector-j.txt" "build\package-input\"
if errorlevel 1 exit /b 1
copy /Y "lib\mysql-connector-j-8.4.0-sources.jar" "build\package-input\"
if errorlevel 1 exit /b 1

> "build\manifest.mf" echo Manifest-Version: 1.0
>>"build\manifest.mf" echo Main-Class: Main
>>"build\manifest.mf" echo Class-Path: lib/mysql-connector-j-8.4.0.jar
>>"build\manifest.mf" echo.
jar cfm "build\package-input\ReservationApp.jar" "build\manifest.mf" -C out .
if errorlevel 1 exit /b 1

if not exist "dist" mkdir "dist"
if not exist "dist\licenses" mkdir "dist\licenses"
copy /Y "lib\LICENSE-mysql-connector-j.txt" "dist\licenses\"
if errorlevel 1 exit /b 1
copy /Y "lib\mysql-connector-j-8.4.0-sources.jar" "dist\licenses\"
if errorlevel 1 exit /b 1

jpackage --type app-image --input "build\package-input" --dest "dist" --name "ReservationClient" --app-version "1.0.0" --vendor "ReservationApp" --main-jar "ReservationApp.jar" --main-class "Main"
if errorlevel 1 exit /b 1
jpackage --type app-image --input "build\package-input" --dest "dist" --name "ReservationServer" --app-version "1.0.0" --vendor "ReservationApp" --main-jar "ReservationApp.jar" --main-class "ReservationServer" --win-console
if errorlevel 1 exit /b 1

powershell -NoProfile -Command "Compress-Archive -Path 'dist\ReservationClient','dist\ReservationServer','dist\licenses','src','sql','README.md','build.bat','run-client.bat','run-server.bat','package-windows.bat' -DestinationPath 'dist\ReservationApp-Windows.zip' -CompressionLevel Optimal"
if errorlevel 1 exit /b 1

echo Executables crees :
echo   dist\ReservationServer\ReservationServer.exe
echo   dist\ReservationClient\ReservationClient.exe
echo   dist\ReservationApp-Windows.zip
echo Sources et licence JDBC : dist\licenses
exit /b 0
