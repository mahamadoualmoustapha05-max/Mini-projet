# Gestion des réservations de salles (Java : Swing, Threads, Sockets, JDBC, fichiers)

## 1. Prérequis
- JDK 17 ou plus récent
- MySQL 8 (ou MariaDB) démarré
- MySQL Connector/J 8.4.0 dans `lib/mysql-connector-j-8.4.0.jar` (le pilote et sa licence/source sont fournis dans `lib/`)

## 2. Mise en place
1. Créer la base : `mysql -u root -p < sql/schema.sql`
   (ou ouvrir `sql/schema.sql` dans MySQL Workbench et l'exécuter)
2. Initialiser la base une seule fois : `sql/schema.sql` ne supprime pas les données existantes et peut être relancé sans dupliquer les comptes, salles ou exemples.
3. Compiler : `build.bat` (Windows) ou `./build.sh` (Linux/Mac)
4. Lancer le serveur : `run-server.bat` — modifier `-Ddb.user` / `-Ddb.password` si besoin
5. Lancer un ou plusieurs clients : `run-client.bat` (autant de fois que voulu)

### Executables Windows

Exécuter `package-windows.bat` depuis Windows avec un JDK 17+ disponible dans `PATH`.
Les images autonomes sont créées sous `dist/` :

- `dist/ReservationServer/ReservationServer.exe` : démarrer d'abord ce serveur après MySQL.
- `dist/ReservationClient/ReservationClient.exe` : lancer ensuite l'interface graphique.
- `dist/ReservationApp-Windows.zip` : archive transportable des deux images et des documents de licence.
- `dist/licenses/` : licence et sources de MySQL Connector/J.

MySQL reste un prérequis externe. Les identifiants par défaut sont `root` sans mot de passe ; adaptez `db.user` et `db.password` dans `run-server.bat` ou dans la configuration du lanceur serveur si votre MySQL utilise d'autres identifiants.

Comptes de test : `admin@res.ma / admin123` (ADMIN) — `user1@res.ma`, `user2@res.ma`, `user3@res.ma` / `user123`.

## 3. Architecture
```
Client Swing ──(Request / Response sérialisés, TCP :5000)──► ReservationServer
  LoginFrame, MainFrame                                        └─ 1 thread ClientHandler par client
  Dashboard / Reservation / Salle panels                           └─ DAO (JDBC) ──► MySQL ReservationDB
  Async (SwingWorker) ─► ReservationClient (Socket)                └─ FileManager (logs.txt)
```
| Exigence | Où |
|---|---|
| Tables, clés, données de test | `sql/schema.sql` |
| `DatabaseConnection`, CRUD JDBC | `DatabaseConnection`, `ReservationDAO`, `SalleDAO`, `UtilisateurDAO` |
| Sockets, `Request`/`Response`, Object streams | `ReservationServer`, `ReservationClient`, `Request`, `Response` |
| Threads | `ClientHandler implements Runnable` (un `Thread` par client) |
| Anti-conflit garanti par la base | `ReservationDAO.lockAndCheck` : transaction + `SELECT ... FOR UPDATE` sur la salle, puis test de chevauchement |
| Swing | `LoginFrame`, `MainFrame`, `DashboardPanel`, `ReservationPanel`, `SallePanel` |
| Non-blocage de l'interface | `Async` (SwingWorker) |
| Fichiers | `FileManager` : `logs.txt`, export CSV, sauvegarde/lecture binaire (.ser) |

## 4. Tests (serveur démarré)
- `java -cp "out;lib/*" CrudTest` : authentification, CRUD, droits, CSV, binaire, perte de connexion (code de sortie non nul en cas d'échec)
- `java -cp "out;lib/*" ConcurrencyTest [idSalle]` : 3 clients simultanés, créneaux qui se chevauchent → un seul accepté (avec délais d'attente et code de sortie non nul en cas d'échec)
- Perte de connexion en vrai : connectez un client, arrêtez le serveur (Ctrl+C), cliquez sur une action → message + retour à l'écran de connexion.
