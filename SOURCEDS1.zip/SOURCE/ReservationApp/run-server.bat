@echo off
cd /d "%~dp0"
rem Adaptez -Ddb.user / -Ddb.password a votre MySQL
java -Ddb.user=root -Ddb.password= -cp "out;lib/*" ReservationServer
