@echo off
setlocal
cd /d "%~dp0"
if not exist out mkdir out
javac -encoding UTF-8 -d out src\*.java
if errorlevel 1 (
    echo ERREUR : la compilation a echoue.
    exit /b 1
)
echo Compilation terminee.
exit /b 0
