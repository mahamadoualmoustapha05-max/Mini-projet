-- =====================================================
-- ReservationDB : création des tables + données de test
-- Exécution :  mysql -u root -p < sql/schema.sql
-- =====================================================
SET NAMES utf8mb4;   -- évite les problèmes d'accents quelle que soit la console
CREATE DATABASE IF NOT EXISTS ReservationDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ReservationDB;

CREATE TABLE IF NOT EXISTS Utilisateur (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nom         VARCHAR(100) NOT NULL,
    email       VARCHAR(100) NOT NULL UNIQUE,
    motDePasse  VARCHAR(64)  NOT NULL,              -- hash SHA-256 (hexadécimal)
    role        ENUM('ADMIN','USER') NOT NULL DEFAULT 'USER'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Salle (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nom         VARCHAR(100) NOT NULL UNIQUE,
    type        VARCHAR(50)  NOT NULL,
    capacite    INT          NOT NULL CHECK (capacite > 0),
    disponible  BOOLEAN      NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Reservation (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    idUtilisateur  INT  NOT NULL,
    idSalle        INT  NOT NULL,
    date           DATE NOT NULL,
    heureDebut     TIME NOT NULL,
    heureFin       TIME NOT NULL,
    motif          VARCHAR(255),
    statut         ENUM('CONFIRMEE','ANNULEE') NOT NULL DEFAULT 'CONFIRMEE',
    CONSTRAINT fk_res_user  FOREIGN KEY (idUtilisateur) REFERENCES Utilisateur(id),
    CONSTRAINT fk_res_salle FOREIGN KEY (idSalle) REFERENCES Salle(id) ON DELETE CASCADE,
    CONSTRAINT chk_heures   CHECK (heureFin > heureDebut),
    INDEX idx_salle_date (idSalle, date)
) ENGINE=InnoDB;

-- Mots de passe : admin123 pour l'admin, user123 pour les autres
INSERT INTO Utilisateur (nom, email, motDePasse, role) VALUES
 ('Administrateur', 'admin@res.ma', SHA2('admin123',256), 'ADMIN'),
 ('Utilisateur Un',   'user1@res.ma', SHA2('user123',256),  'USER'),
 ('Utilisateur Deux', 'user2@res.ma', SHA2('user123',256),  'USER'),
 ('Utilisateur Trois','user3@res.ma', SHA2('user123',256),  'USER')
ON DUPLICATE KEY UPDATE nom = VALUES(nom), motDePasse = VALUES(motDePasse), role = VALUES(role);

INSERT INTO Salle (nom, type, capacite, disponible) VALUES
 ('Salle A101',        'Cours',         40,  TRUE),
 ('Labo Info 1',       'Laboratoire',   25,  TRUE),
 ('Amphi Ibn Tofail',  'Amphithéâtre',  200, TRUE),
 ('Salle de réunion R1','Réunion',      12,  TRUE),
 ('Salle B202',        'Cours',         30,  FALSE)
ON DUPLICATE KEY UPDATE type = VALUES(type), capacite = VALUES(capacite), disponible = VALUES(disponible);

INSERT INTO Reservation (idUtilisateur, idSalle, date, heureDebut, heureFin, motif, statut)
SELECT 2, 1, CURDATE() + INTERVAL 1 DAY, '08:00', '10:00', 'Cours de Java', 'CONFIRMEE'
WHERE NOT EXISTS (
    SELECT 1 FROM Reservation
    WHERE idUtilisateur = 2 AND idSalle = 1 AND date = CURDATE() + INTERVAL 1 DAY AND motif = 'Cours de Java'
);
INSERT INTO Reservation (idUtilisateur, idSalle, date, heureDebut, heureFin, motif, statut)
SELECT 3, 2, CURDATE() + INTERVAL 1 DAY, '14:00', '16:00', 'TP Réseaux', 'CONFIRMEE'
WHERE NOT EXISTS (
    SELECT 1 FROM Reservation
    WHERE idUtilisateur = 3 AND idSalle = 2 AND date = CURDATE() + INTERVAL 1 DAY AND motif = 'TP Réseaux'
);
INSERT INTO Reservation (idUtilisateur, idSalle, date, heureDebut, heureFin, motif, statut)
SELECT 2, 4, CURDATE() + INTERVAL 2 DAY, '09:00', '10:00', 'Réunion de projet', 'ANNULEE'
WHERE NOT EXISTS (
    SELECT 1 FROM Reservation
    WHERE idUtilisateur = 2 AND idSalle = 4 AND date = CURDATE() + INTERVAL 2 DAY AND motif = 'Réunion de projet'
);
